#!/usr/bin/sh

for i in B C E F L P S Y
	do
	for j in B C E F L P S Y
		do
		for k in snps diff delta coords
			do
				rm $i*-$j*$k
			done
		done
	done
done
